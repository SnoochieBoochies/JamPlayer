/** Automatically generated file. DO NOT MODIFY */
package com.loopj.android.http;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}